package com.anz.banking.facades;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.anz.banking.models.Car;
@Transactional
public interface CarMongoRepository extends MongoRepository<Car, String>{

}
