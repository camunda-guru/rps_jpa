package com.cog.tests;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cog.dao.DaoManager;
import com.cog.entities.CreditCard;
import com.cog.entities.Payment;

public class PaymentTest {
	private DaoManager dao;
	@Before
	public void setUp() throws Exception {
		dao=new DaoManager();
	}

	@After
	public void tearDown() throws Exception {
	}

	/*@Test
	public void PaymentObjTest() {
		//fail("Not yet implemented");
	   
		Payment payment=new Payment();
		payment.setAmount(10000);
		payment.setDOT(new Date(116,5,5));
		assertTrue( dao.AddPayment(payment));
		
		
	}*/
	@Test
	public void CreditCardObjTest() {
		//fail("Not yet implemented");
	   
		CreditCard payment=new CreditCard();
		payment.setCustomerId(43856);
		payment.setAmount(10000);
		payment.setDOT(new Date(116,5,5));
		payment.setCreditcardNo(487584);
		payment.setCvv(455);
		payment.setcName("Master");
		payment.setcExpiryDate(new Date(121,1,7));
		payment.setEMI(false);
		assertTrue( dao.AddPayment(payment));
		
		
	}
	
	
	

}
