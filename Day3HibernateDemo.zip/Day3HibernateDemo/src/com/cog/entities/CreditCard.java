package com.cog.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="CreditCard")
/*@DiscriminatorValue(value="CreditCardObj")*/
public class CreditCard  extends Payment{
	@Column(name="CreditCardNo")
	private long creditcardNo;
	@Column(name="C_CVV")
	private int cvv;
	@Column(name="C_Name")
	private String cName;
	@Temporal(TemporalType.DATE)
	@Column(name="C_ExpiryDate")
	private Date cExpiryDate;
	@Column(name="EMI")
	private boolean EMI;
	public long getCreditcardNo() {
		return creditcardNo;
	}
	public void setCreditcardNo(long creditcardNo) {
		this.creditcardNo = creditcardNo;
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public Date getcExpiryDate() {
		return cExpiryDate;
	}
	public void setcExpiryDate(Date cExpiryDate) {
		this.cExpiryDate = cExpiryDate;
	}
	public boolean isEMI() {
		return EMI;
	}
	public void setEMI(boolean eMI) {
		EMI = eMI;
	}

}
