package com.ge.insurance.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ge.insurance.entities.StockExchange;
import com.ge.insurance.repositories.InsuranceRepository;

@Controller
public class InsuranceController {
    @Autowired
	private InsuranceRepository repository;
    @RequestMapping(value = "/home", method = RequestMethod.GET)
    public String home()
    {
    	return "Application is up!....";
    }
    
    @RequestMapping(value = "/addStock", method = RequestMethod.POST)
	public String addStock(StockExchange stock)
	{
		repository.save(stock);
		return "Object added";
		
	}
}
