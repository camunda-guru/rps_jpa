package com.ge.insurance.repositories;

import org.springframework.data.repository.CrudRepository;

import com.ge.insurance.entities.StockExchange;

public interface InsuranceRepository extends CrudRepository<StockExchange,String>{

}
