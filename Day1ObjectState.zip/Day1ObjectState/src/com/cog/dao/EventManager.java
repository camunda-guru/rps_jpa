package com.cog.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cog.entities.Event;
import com.cog.resources.HibernateUtil;

public class EventManager {

	private SessionFactory factory;
	private Session session;
	public EventManager()
	{
		factory=HibernateUtil.GetFactory();
	}
	
	public boolean AddEvent(Event event)
	{
		boolean status=false;
		session=factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(event);
			session.getTransaction().commit();
			status=true;
		}
		catch(HibernateException hib)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	
	
}
