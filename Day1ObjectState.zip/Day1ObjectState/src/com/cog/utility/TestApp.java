package com.cog.utility;

import java.util.Scanner;

import com.cog.dao.EventManager;
import com.cog.dao.RoomManager;
import com.cog.entities.Event;
import com.cog.entities.EventKey;
import com.cog.entities.Room;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EventManager eventmanager=new EventManager();
		EventKey eventkey =new EventKey();
		eventkey.setEventId(1);
		eventkey.setTrainerId(249);
		Event event =new Event();
		event.setEventid(eventkey);
		event.setDuration(5);
		event.setLocation("Chennai");
		event.setEventName("Hibernate Training");
		eventmanager.AddEvent(event);
		
		
		
		
		
		
           // RoomManager roomManager =new RoomManager();
           /* Room room =new Room();
            room.setCapacity(25);
            room.setLocation("ASV Sun Tech");
            room.setProjector_Avl(true);
            room.setSystem_Avl(true);
           if( roomManager.AddRoom(room))
        	   System.out.println("Record Added");*/
            
        /*    for(Room room : roomManager.GetAllRooms())
            {
            	System.out.print(room.getRoomNo()+"\t");
            	System.out.println(room.getCapacity());
            }
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter Room No1");
            int roomNo1=scanner.nextInt();
            roomManager.SessionClose(roomNo1);*/
            /*int roomNo1=scanner.nextInt();
            System.out.println("Enter Room No2");
            int roomNo2=scanner.nextInt();
            roomManager.roomEvict_Clear(roomNo1, roomNo2);*/
            //roomManager.DeleteRoom(roomNo);
	}

}
