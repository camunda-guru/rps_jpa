package com.cog.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="Author")
public class Author {
	@Id
    @Column(name="Author_Id")
    @GeneratedValue(generator="gen")
    @GenericGenerator(name="gen", strategy="foreign",
    parameters=@Parameter(name="property", value="book"))
	private int authorId;
	@Column(name="Author_Name")
	private String authorName;
	@OneToOne
    @PrimaryKeyJoinColumn
	private Book book;
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
}
