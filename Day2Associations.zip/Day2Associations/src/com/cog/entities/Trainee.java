package com.cog.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.JoinColumn;
@Entity
@Table(name="Trainee")
public class Trainee {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Trainee_Id")
    private int traineeId;
	@Column(name="Trainee_Name")
    private String traineeName;
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name = "Trainee_Course", 
    joinColumns = { @JoinColumn(name = "Trainee_Id") }, 
    inverseJoinColumns = { @JoinColumn(name = "Course_Id") })
    private List<Course> courseList;
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public List<Course> getCourseList() {
		return courseList;
	}
	public void setCourseList(List<Course> courseList) {
		this.courseList = courseList;
	}
	
	
}
